package com.example.fragment;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import com.example.fragment.R;
import com.example.fragment.SharedViewModel;
public class FragmentB extends Fragment {

    private SharedViewModel sharedViewModel;
    private TextView productName, productDescription, productPrice;
    private Button A13, F1, Pro15;

    @SuppressLint("MissingInflatedId")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_b, container, false);

        // Inisialisasi ViewModel
        sharedViewModel = new ViewModelProvider(requireActivity()).get(SharedViewModel.class);

        // Inisialisasi Views
        productName = view.findViewById(R.id.productName);
        productDescription = view.findViewById(R.id.productDescription);
        productPrice = view.findViewById(R.id.productPrice);
        A13 = view.findViewById(R.id.Samsung);
        F1 = view.findViewById(R.id.Oppo);
        Pro15 = view.findViewById(R.id.Iphone);

        // Mengamati produk yang dipilih
        sharedViewModel.getSelectedProduct().observe(getViewLifecycleOwner(), product -> {
            if (product != null) {
                productName.setText(product.getName());
                productDescription.setText(product.getDescription());
                productPrice.setText("Rp " + product.getPrice());
            }
        });

        return view;
    }
}